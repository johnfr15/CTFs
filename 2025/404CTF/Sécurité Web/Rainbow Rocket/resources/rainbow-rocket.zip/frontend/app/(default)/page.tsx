import Hero from '@/components/hero'
import Features from '@/components/features'
import React from 'react';



function Home() {


  return (
    <>
      <Hero />
      <Features />
    </>
  );
}

export default Home;