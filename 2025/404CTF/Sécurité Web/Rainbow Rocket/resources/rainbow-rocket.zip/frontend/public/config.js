window.ENV = {
    BACKEND_URL: "https://rainbow-rocket.404ctf.fr/api"
  };
  