#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

void intro() {
   puts("⠀⠀⡀⠀⠀⠀⣀⣠⣤⣤⣤⣤⣤⣤⣤⣤⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀                                      ");
   puts("⠀⠘⢿⣝⠛⠋⠉⠉⠉⣉⠩⠍⠉⣿⠿⡭⠉⠛⠃⠲⣞⣉⡙⠿⣇⠀⠀⠀                                      ");
   puts("⠀⠀⠈⠻⣷⣄⡠⢶⡟⢁⣀⢠⣴⡏⣀⡀⠀⠀⣠⡾⠋⢉⣈⣸⣿⡀⠀⠀                                      ");
   puts("⠀⠀⠀⠀⠙⠋⣼⣿⡜⠃⠉⠀⡎⠉⠉⢺⢱⢢⣿⠃⠘⠈⠛⢹⣿⡇⠀⠀                                      ");
   puts("⠀⠀⠀⢀⡞⣠⡟⠁⠀⠀⣀⡰⣀⠀⠀⡸⠀⠑⢵⡄⠀⠀⠀⠀⠉⠀⣧⡀                                      ");
   puts("⠀⠀⠀⠌⣰⠃⠁⣠⣖⣡⣄⣀⣀⣈⣑⣔⠂⠀⠠⣿⡄⠀⠀⠀⠀⠠⣾⣷   SPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
   puts("⠀⠀⢸⢠⡇⠀⣰⣿⣿⡿⣡⡾⠿⣿⣿⣜⣇⠀⠀⠘⣿⠀⠀⠀⠀⢸⡀⢸   AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
   puts("⠀⠀⡆⢸⡀⠀⣿⣿⡇⣾⡿⠁⠀⠀⣹⣿⢸⠀⠀⠀⣿⡆⠀⠀⠀⣸⣤⣼   AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
   puts("⠀⠀⢳⢸⡧⢦⢿⣿⡏⣿⣿⣦⣀⣴⣻⡿⣱⠀⠀⠀⣻⠁⠀⠀⠀⢹⠛⢻   AAAAAAAAAAAAAAAAAAAAAAAAAAAAACE    ");
   puts("⠀⠀⠈⡄⢷⠘⠞⢿⠻⠶⠾⠿⣿⣿⣭⡾⠃⠀⠀⢀⡟⠀⠀⠀⠀⣹⠀⡆                                      ");
   puts("⠀⠀⠀⠰⣘⢧⣀⠀⠙⠢⢤⠠⠤⠄⠊⠀⠀⠀⣠⠟⠀⠀⠀⠀⠀⢧⣿⠃                                      ");
   puts("⠀⣀⣤⣿⣇⠻⣟⣄⡀⠀⠘⣤⣣⠀⠀⠀⣀⢼⠟⠀⠀⠀⠀⠀⠄⣿⠟⠀                                      ");
   puts("⠿⠏⠭⠟⣤⣴⣬⣨⠙⠲⢦⣧⡤⣔⠲⠝⠚⣷⠀⠀⠀⢀⣴⣷⡠⠃⠀⠀                                      ");
   puts("⠀⠀⠀⠀⠀⠉⠉⠉⠛⠻⢛⣿⣶⣶⡽⢤⡄⢛⢃⣒⢠⣿⣿⠟⠀⠀⠀⠀                                      ");
   puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠉⠉⠉⠁⠀⠁⠀⠀⠀⠀⠀                                      ");
   puts("                                                                        ");
   puts("   ╔═════════════════════════════════════╗                              ");
   puts("   ║        Firmware Updater v1.0        ║                              ");
   puts("   ║                                     ║                              ");
   puts("   ║ Send your update data to space core ║                              ");
   puts("   ╚═════════════════════════════════════╝                              ");
}

void choice(int* res) {
   puts("1. Upload an update");
   puts("2. Run the firmware");
   puts("3. Open a bidirectional connection");
   printf("Enter your choice\n> ");
   scanf("%d", res);
}

void upload_update(long firmware_max_size, void* firmware) {
   ssize_t bytes_read;
   printf("Ready to receive update > ");
   bytes_read = read(0, firmware, firmware_max_size);
}

void apply_update(void* firmware) {
   ((void (*)())firmware)();
}

void bidirectional_connection() {
   puts("SPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACE");
   exit(-1);
}

int main(void) {
   setvbuf(stdin, NULL, _IONBF, 0);
   setvbuf(stdout, NULL, _IONBF, 0);
   setvbuf(stderr, NULL, _IONBF, 0);

   long firmware_max_size = 0xd;
   void *firmware;
   firmware = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
   
   intro();
   int res;

   while (true) {
      choice(&res);
      if (res == 1) {
         upload_update(firmware_max_size, firmware);
      } else if (res == 2) {
         apply_update(firmware);
      } else if (res == 3) {
         bidirectional_connection();
      } else {
         printf("Invalid choice");
      }
   }

   return 0;
}
