from pwn import *

exe = ELF(b'chall')

context.binary = exe

def conn():
    if args.LOCAL:
        r = process([exe.path])
        return r
    else:
        return remote('localhost', 31337)

def your_shellcode():
    shellcode_asm = """
        mov rax, 0xdeadbeef
	"""
    shellcode = asm(shellcode_asm, bits=64)
    print(f"shellcode length : {len(shellcode)} bytes")
    return shellcode

def main():
    global r 
    r = conn()

    # Good luck :)

    r.interactive()

if __name__ == '__main__':
    main()
