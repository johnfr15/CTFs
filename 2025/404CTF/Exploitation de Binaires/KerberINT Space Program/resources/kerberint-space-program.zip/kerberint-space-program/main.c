#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

void welcome_screen(void) {
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠛⠻⣶");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣄⣴⡿");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣠⣤⣀⣠⣾⣽⠛⠛⠉⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣤⣶⣶⡟⢹⠋⣉⣀⠀⠀⠀⠸⣿⣟⠁⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡤⡖⢋⢡⡿⠋⠁⣸⠀⣿⠿⠉⠀⠀⠀⠀⣀⡼⣿⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⣾⣿⠁⠘⡹⢸⣿⣟⠟⠙⡀⢱⡀⠀⣀⣠⣴⣿⣿⣿⡇⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣞⣿⣿⢻⣿⣼⡧⡇⠉⢿⣶⣶⠖⠳⡀⠱⣄⣿⣿⣿⣿⣶⡿⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⣀⣀⣀⣀⠀⣠⠞⢻⣷⣿⣏⡞⣿⣿⣧⣥⣄⣈⢿⣷⣶⣶⠛⢦⡈⠛⢿⣿⣯⣿⡇⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠰⠶⣿⣿⣿⣿⣿⣿⠛⡿⠿⣿⠿⣯⠀⢸⣿⣟⣿⡽⢻⣿⣿⣿⣿⣝⣻⣿⣿⣇⣤⣴⡟⠢⢤⣀⣸⠏⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠈⠙⠿⣿⡟⠁⣺⢃⣾⠋⠀⢹⡀⠈⣿⠟⢸⠁⡿⢿⣟⡛⠻⢿⣿⢻⡏⠛⠿⣿⣇⣴⣿⣷⠋⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⢡⡿⡁⢰⣀⠀⢳⡀⠘⢆⠈⣇⢳⡘⣿⣿⣷⣦⡽⢸⠃⠀⠀⢀⣉⣉⡽⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢙⣿⣁⢳⡆⢿⠀⠀⠳⡀⠈⢣⡈⠢⣙⠺⠽⠿⣟⡡⠋⠀⠀⠤⠽⢫⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⢹⣿⡈⣷⠀⣀⣀⠀⠙⢦⡀⣙⣦⡈⠉⠁⠉⠉⠀⠀⢀⣾⣏⣹⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣰⣧⣾⣧⣷⣾⣿⣿⡿⠇⠀⠀⠙⠦⣓⢎⡲⣤⣀⠀⠀⣠⣼⣿⡿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⣀⣀⠤⠴⣿⣿⣿⣿⡿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠈⠙⠿⣶⣽⣯⣿⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠐⣮⡉⠁⣠⣴⣿⣿⣿⣿⣡⡼⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡤⢿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⣀⣠⠴⠚⠋⣡⠾⠟⢋⣉⣁⣸⣎⠳⡈⠢⣀⡀⠀⠀⠀⠀⡀⣠⣴⣾⣿⣿⣿⢿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠉⢁⣶⠆⠀⠁⠀⠀⠈⠉⣲⡗⣤⣹⣮⣓⢤⣙⡓⠶⣶⣿⣿⣿⣿⡿⠛⠉⠀⢰⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⢴⡿⠥⠤⢤⡄⠀⠀⠀⠐⠓⠛⠋⢻⣿⣿⠓⠦⢭⣙⣒⣶⡾⠉⠹⡄⠀⠀⠀⣼⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⢀⣰⠋⣀⠤⣶⠇⢀⡀⠀⠀⠘⠏⠁⠀⠀⢠⠏⠀⠀⠀⠀⠀⢳⠐⠀⢀⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠐⠛⠋⠉⠀⣰⣯⠴⢻⠁⣠⢶⠀⣰⣆⠀⡠⠁⠀⠀⠀⠀⠀⠀⠘⣦⣾⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠰⠛⠁⠀⣸⠟⠁⣸⡟⠁⢹⡴⠁⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠈⠀⠀⢈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
    puts("░█░█░█▀▀░█▀▄░█▀▄░█▀▀░█▀▄░▀█▀░█▀█░▀█▀░░░█▀▀░█▀█░█▀█░█▀▀░█▀▀");
    puts("░█▀▄░█▀▀░█▀▄░█▀▄░█▀▀░█▀▄░░█░░█░█░░█░░░░▀▀█░█▀▀░█▀█░█░░░█▀▀");
    puts("░▀░▀░▀▀▀░▀░▀░▀▀░░▀▀▀░▀░▀░▀▀▀░▀░▀░░▀░░░░▀▀▀░▀░░░▀░▀░▀▀▀░▀▀▀");
    puts("░█▀█░█▀▄░█▀█░█▀▀░█▀▄░█▀█░█▄█                              ");
    puts("░█▀▀░█▀▄░█░█░█░█░█▀▄░█▀█░█░█                              ");
    puts("░▀░░░▀░▀░▀▀▀░▀▀▀░▀░▀░▀░▀░▀░▀                              ");
}

void menu(void) {
    puts("-----------------|KSP|-----------------");
    puts("1. Create your rocket                  ");
    puts("2. Edit your rocket price              ");
    puts("3. Edit your rocket name               ");
    puts("4. Edit your rocket description        ");
    puts("5. Display your rocket metadata        ");
    puts("6. Exit                                ");
}

struct rocket {
    long price;
    char name[0x10];
    char* description;
};

struct rocket *user_rocket = NULL;

void take_input(char *buf, size_t len) {
    char c = -1;
    int i = 0;
    while (i <= len && c != '\n') {
        c = getchar();
        buf[i] = c;
        i++;
    }
    buf[i] = 0;
}

void initialize_rocket() {
    user_rocket = malloc(sizeof(struct rocket));

    printf("Choose the price >> ");
    scanf("%ld", &user_rocket->price);
    getchar();

    printf("Choose its name >> ");
    take_input(user_rocket->name, 0x10);

    user_rocket->description = malloc(0x100);
    printf("Choose its description >> ");
    take_input(user_rocket->description, 0x100);
}

void edit_rocket_price() {
    printf("Choose the price >> ");
    scanf("%ld", &user_rocket->price);
}

void edit_rocket_name() {
    printf("Choose its name >> ");
    take_input(user_rocket->name, strlen(user_rocket->name));
}

void edit_rocket_description() {
    printf("Choose its description >> ");
    take_input(user_rocket->description, 0x100);
}

void display() {
    printf("Price : %ld €\n", user_rocket->price);
    printf("Name : %s\n", user_rocket->name);
    printf("Description : %s\n", user_rocket->description);
}

void free_user_rocket() {
    free(user_rocket->description);
    free(user_rocket);
}

int main(void) {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    long long choice;
    int res;

    welcome_screen();

    user_rocket = NULL;

    while (true) {
        menu();
        printf("Enter your choice\n> ");
        res = scanf("%lld", &choice);
        getchar();
        if (!res) exit(EXIT_FAILURE);

        switch (choice) {
            case 1:
                if (user_rocket == NULL) {
                    initialize_rocket();
                } else {
                    puts("You already have a rocket !");
                }
                break;
            case 2:
                if (user_rocket != NULL) {
                    edit_rocket_price();
                } else {
                    puts("You don't have a rocket !");
                }
                break;
            case 3:
                if (user_rocket != NULL) {
                    edit_rocket_name();
                } else {
                    puts("You don't have a rocket !");
                }
                break;
            case 4:
                if (user_rocket != NULL) {
                    edit_rocket_description();
                } else {
                    puts("You don't have a rocket !");
                }
                break;
            case 5:
                if (user_rocket != NULL) {
                    display();
                } else {
                    puts("You don't have a rocket !");
                }
                break;
            case 6:
                puts("Going to the Mune !");
                free_user_rocket();
                exit(EXIT_SUCCESS);
            default:
                puts("Invalid!!!");
                exit(choice);
        }
    }
    return 0;
}
